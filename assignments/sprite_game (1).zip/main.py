# importing libraries
import pygame
import asyncio
import math

# importing project modules
import game

async def main():
	# Initialising game
    game_window = game.init()
    background = pygame.image.load('dark_background.png').convert()
    class Card():
        suit_names = ['clubs', 'diamonds', 'hearts', 'spades']
        rank_names = [None, 'ace', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'jack', 'queen', 'king']
        def __init__(self, suit=0, rank=2):
            self.suit = suit
            self.rank = rank
        def __str__(self):
            return '%s of %s' % (Card.rank_names[self.rank], Card.suit_names[self.suit])
        def __lt__(self, other):
            if self.suit < other.suit: return True 
            if self.suit > other.suit: return False
            return self.rank < other.rank
    
    class Deck(pygame.sprite.Sprite):
         def __init__(self):
            self.cards = []
            for suit in range (4):
                for rank in range (1,14): 
                    card = Card(suit, rank)
                    self.cards.append(card)
            self.image = pygame.transform.scale(pygame.image.load("cards/card_back_purple.png").convert_alpha(), (100,140))
            self.rect = self.image.get_rect()
            self.rect.center = (game.window_x / 1.5, game.window_y - 250)
            pygame.sprite.Sprite.__init__(self)
         def __str__(self):
            res = []
            for card in self.cards: 
                res.append(str(card))
            return '/n'.join(res)
         def pop_card(self):
            return self.cards.pop()
         def add_card(self, card):
            self.cards.append(card)
         def shuffle(self):
            random.shuffle(self.cards)
    class Hand(Deck):
        def __init__(self):
            self.cards = []
            card = "cards/%s_of_%s.png" % (Card.rank_names[self.rank], Card.suit_names[self.suit])
            self.image = pygame.transform.scale(pygame.image.load(card).convert_alpha(), (100,125))
            self.rect = self.image.get_rect()
            self.rect.center = (game.window_x / 2, game.window_y - 50)
            super().__init__(self)
        def move_cards(self, hand, num):
            for i in range(num):
                hand.add_card(self.pop_card())

    # Gruppi di sprite
    all_sprites = pygame.sprite.Group()

    deck = Deck()
    all_sprites.add(deck)

    #cards = Card()
    #all_sprites.add(cards)

    #hand = Hand()
    #all_sprites.add(hand)

    deal_card = False
    while not deal_card:
        # RGB - Red, Green, Blue
        game_window.fill((0, 0, 0))

        # Background Image
        game_window.blit(background, (0, 0))

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_DOWN:
                    removed_card = deck.pop_card()
                    print(removed_card)
                if event.key == pygame.K_UP:
                    deck.shuffle() 


        all_sprites.update()
        all_sprites.draw(game_window)

        game.update(game_window)
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())