import pygame
import asyncio
import math

# importing project modules
import game

async def main():
    # Initialising game
    game_window = game.init()
    background = pygame.image.load('background.png').convert()

    scroll = 0
    tiles = math.ceil(game.window_x / background.get_width()) + 1
    print(tiles)

    class Player(pygame.sprite.Sprite):
        def __init__(self):
            super().__init__()
            self.image = pygame.transform.scale(pygame.image.load('car.png').convert_alpha(), (400, 300))
            self.rect = self.image.get_rect()
            self.rect.center = (game.window_x / 2, game.window_y - 450)
            self.speed = 8  # Increased speed

            # Create a smaller collision rectangle
            self.collision_rect = pygame.Rect(self.rect.x + 50, self.rect.y + 50, 300, 200)

        # movement of the car 
        def update(self):
            car_change_x = 0
            car_change_y = 0
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT]:
                car_change_x = -self.speed
            if keys[pygame.K_RIGHT]:
                car_change_x = self.speed
            if keys[pygame.K_UP]:
                car_change_y = -self.speed
            if keys[pygame.K_DOWN]:
                car_change_y = self.speed

            # Update car position
            self.rect.x += car_change_x
            self.rect.y += car_change_y

            # Update collision rectangle position
            self.collision_rect.x = self.rect.x + 50
            self.collision_rect.y = self.rect.y + 50

    class Enemy(pygame.sprite.Sprite):
        def __init__(self, center_x, center_y, radius):
            super().__init__()
            self.image = pygame.image.load('obstacle.png').convert_alpha()
            self.image = pygame.transform.scale(self.image, (200, 200))
            self.rect = self.image.get_rect()
            self.rect.center = (center_x, center_y)
            self.speed = 30  # Increased speed

            # Create a smaller collision rectangle
            self.collision_rect = pygame.Rect(self.rect.x + 50, self.rect.y + 50, 100, 100)

        def update(self):
            # Move the enemy horizontally
            self.rect.x += self.speed

            # Update collision rectangle position
            self.collision_rect.x = self.rect.x + 50
            self.collision_rect.y = self.rect.y + 50

            # If the enemy goes off the screen, reset its position
            if self.rect.left > game.window_x:
                self.rect.right = 0

    # Gruppi di sprite
    all_sprites = pygame.sprite.Group()
    enemies = pygame.sprite.Group()

    player = Player()
    all_sprites.add(player)

    enemy = Enemy(game.window_x / 5, game.window_y - 50, 50)
    all_sprites.add(enemy)
    enemies.add(enemy)

    game_over = False
    while not game_over:
        # RGB - Red, Green, Blue
        game_window.fill((0, 0, 0))
        print(game_over)

        i = 0
        while i < tiles:
            game_window.blit(background, (0, background.get_height() * i - scroll))
            i += 1
        
        scroll += 6

        if scroll > background.get_height():
            scroll = 0
   

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True

        all_sprites.update()
        all_sprites.draw(game_window)

        # Check for collisions between player and enemies
        for enemy in enemies:
            if player.collision_rect.colliderect(enemy.collision_rect):
                print("Game Over")
                game_over = True
                break

        pygame.display.update()
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())